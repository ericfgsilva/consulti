
// AMD Compliance
if ('function' === typeof define && define.amd)
  define('parsley', function() { return window.Parsley; } );

})(window.jQuery);

